# The JUCE API Reference

From here, you can generate an offline HTML version of the JUCE API Reference.

How to:

1. install doxygen
2. cd into this directory on the command line
3. run `make`
4. doxygen will create a new subfolder "doc" - open doc/index.html in your browser to access the generated HTML documentation
